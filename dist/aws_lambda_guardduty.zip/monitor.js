const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { UpdateCommand } = require("@aws-sdk/lib-dynamodb");

// Initialize the DynamoDB client
const client = new DynamoDBClient({ region: process.env.REGION });

const updateMonitorStatus = async (findingId, ip, status) => {
    // Check if all required parameters are provided
    if (!findingId || !ip || !status) {
        throw new Error("Missing required parameters for updating monitor status.");
    }

    const params = {
        TableName: process.env.DDB_TABLE_NAME,
        Key: { finding_id: findingId, "value ip": ip }, // Use "value ip" instead of value_ip
        UpdateExpression: 'SET #status = :status',
        ExpressionAttributeNames: { '#status': 'status' },
        ExpressionAttributeValues: { ':status': status },
        ReturnValues: 'ALL_NEW'
    };

    try {
        const data = await client.send(new UpdateCommand(params));
        console.log("Monitor status updated successfully:", data);
        return data;
    } catch (error) {
        console.error("Update monitor status error:", error);
        throw new Error("Update monitor status error");
    }
};

const handler = async (event) => {
    console.log("Received event:", JSON.stringify(event, null, 2));

    // Extracting values from the event
    const findingId = event.id; // Assuming this is the finding ID
    const ip = event.detail?.service?.action?.networkConnectionAction?.remoteIpDetails?.ipAddressV4;
    const status = event.detail?.severity; // Assuming severity is the status you want to store

    console.log("Attempting to update monitor status:", { findingId, ip, status });

    try {
        await updateMonitorStatus(findingId, ip, status);
        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Monitor status updated successfully" })
        };
    } catch (error) {
        console.error("Error updating monitor status:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                msg: "There's a problem updating monitor status. Please see detailed information in CloudWatch logs.",
                detail: error.message
            })
        };
    }
};

module.exports = { handler };
