'use strict';

/*
Author: Fortinet

This generator script handles the creation of the static IP block list resource in the S3 bucket.
Information about the Lambda function and configuration is provided in the main script: index.js.

Required IAM permissions:
S3: ListBucket, HeadBucket, GetObject, PutObject, PutObjectAcl
DynamoDB: Scan, UpdateItem

*/

const respArr = [];

// Import required AWS SDK v3 clients
const { S3Client, HeadBucketCommand, GetObjectCommand, PutObjectCommand } = require('@aws-sdk/client-s3');
const { DynamoDBClient, ScanCommand } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

let s3Client = null;
let docClient = null;

/*
 * set response for callback
 */
const setResp = (msg, detail) => {
    respArr.push({
        msg: msg,
        detail: detail
    });
};

/*
 * clear response for callback
 */
const unsetResp = () => {
    respArr.length = 0;
};

/*
 * check if bucket exists
 */
const bucketExists = async () => {
    const params = {
        Bucket: process.env.S3_BUCKET
    };
    try {
        await s3Client.send(new HeadBucketCommand(params));
        console.log('called bucketExists: no error.'); // successful response
        return params.Bucket;
    } catch (err) {
        console.log('called bucketExists and return error: ', err.stack);
        throw err;
    }
};

/*
 * scan the IP block list table and return a set of IP block list
 * return a promise to resolve a list of the table items.
 */
const scanDBTable = async () => {
    const params = {
        TableName: process.env.DDB_TABLE_NAME
    };
    try {
        const data = await docClient.send(new ScanCommand(params));
        console.log('called scanDBTable: scan completed.');
        return data.Items;
    } catch (err) {
        console.log('call scanDBTable: return error', err.stack);
        throw err;
    }
};

/*
 * get the block list file
 */
const getBlockListFile = async () => {
    try {
        const data = await s3Client.send(new GetObjectCommand({
            Bucket: process.env.S3_BUCKET,
            Key: process.env.S3_BLOCKLIST_KEY
        }));
        return data.Body.toString('ascii');
    } catch (err) {
        if (err.name === 'NoSuchKey') {
            return ''; // The file doesn't exist, return empty
        }
        console.log('called getBlockListFile and return error: ', err.stack);
        throw new Error('Get IP block list error.');
    }
};

/*
 * save the block list file
 */
const saveBlockListFile = async (items, blockList) => {
    let found = new Set(),
        added = 0;

    items.forEach(finding => {
        if (blockList.indexOf(finding.ip) < 0) {
            blockList += `${finding.ip}\r\n`;
            added++;
        }
        found.add(finding.ip);
    });

    const params = {
        Body: blockList,
        Bucket: process.env.S3_BUCKET,
        Key: process.env.S3_BLOCKLIST_KEY,
        ACL: 'public-read',
        ContentType: 'text/plain'
    };

    try {
        await s3Client.send(new PutObjectCommand(params));
        console.log('called saveBlockListToBucket: no error.');
        let msg = `${found.size} IP addresses found, and ${added} new IP addresses have been added to IP block list.`;
        setResp(msg, {
            found: found.size,
            added: added
        });
    } catch (err) {
        console.log('called saveBlockListToBucket and return error: ', err.stack);
        throw new Error('Put IP block list error');
    }
};

exports.handler = async (event, context, callback) => {
    // Initialize AWS clients
    s3Client = new S3Client({ region: process.env.REGION });
    const client = new DynamoDBClient({ region: process.env.REGION });
    docClient = DynamoDBDocumentClient.from(client);

    unsetResp();

    // Verify all required process env variables
    if (!process.env.REGION) {
        setResp('Must specify an AWS region.', null);
        callback(null, respArr);
        return;
    }

    if (!process.env.S3_BUCKET || !process.env.S3_BLOCKLIST_KEY) {
        setResp('Must specify the S3 bucket and the IP block list file.', null);
        callback(null, respArr);
        return;
    }

    if (!process.env.DDB_TABLE_NAME) {
        setResp('Must specify an AWS DB Table name.', null);
        callback(null, respArr);
        return;
    }

    try {
        unsetResp();
        // Scan the DynamoDB table to get all IP records
        let ipRecords = await scanDBTable();
        // Check if S3 bucket exists.
        await bucketExists();
        // Get the current block list
        let blockList = await getBlockListFile();
        // Update and save the IP block list file
        await saveBlockListFile(ipRecords, blockList);
    } catch (err) {
        setResp(
            "There's a problem in generating IP block list. Please see detailed" +
                ' information in CloudWatch logs.',
            null
        );
    } finally {
        callback(null, respArr);
    }
};
